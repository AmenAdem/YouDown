
import sys
import os
import time
from pafy import new

print(""" █████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗
╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝
██╗   ██╗ ██████╗ ██╗   ██╗██████╗  ██████╗ ██╗    ██╗███╗   ██╗
╚██╗ ██╔╝██╔═══██╗██║   ██║██╔══██╗██╔═══██╗██║    ██║████╗  ██║
 ╚████╔╝ ██║   ██║██║   ██║██║  ██║██║   ██║██║ █╗ ██║██╔██╗ ██║
  ╚██╔╝  ██║   ██║██║   ██║██║  ██║██║   ██║██║███╗██║██║╚██╗██║
   ██║   ╚██████╔╝╚██████╔╝██████╔╝╚██████╔╝╚███╔███╔╝██║ ╚████║
   ╚═╝    ╚═════╝  ╚═════╝ ╚═════╝  ╚═════╝  ╚══╝╚══╝ ╚═╝  ╚═══╝
            ██╗            ██╗           ██████╗
           ███║           ███║           ╚════██╗
           ╚██║           ╚██║            █████╔╝
            ██║            ██║           ██╔═══╝ 
            ██║    ██╗     ██║    ██╗    ███████╗
            ╚═╝    ╚═╝     ╚═╝    ╚═╝    ╚══════╝
█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗
╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝
""")



print("\n\n\n")
print("download Format :: \n [1] mp3 \n [2] mp4   ")
rep=int(input("-> "))
try: 
    f=open("links.txt","r+")
except:
    f=open("links.txt","w")
    print("no links on links.txt !!")
    exit()
t=open("log.txt","a+")
link=f.readlines()
cp=1
h=' #  '
if(rep==2):
    for i in link:
        video=new(i)
        n=video.title
        print(" \n +++++ start download  +++++  ",n)
        v=video.getbest(preftype="mp4")
        v.download()
        t.write("\n +++++mp4++++ \n ")
        t.write(h)
        t.write(n)
        t.write(": \n ")
        t.write(i)
        t.write("\n =========================================== \n \n \n \n ")
        print(" \n video :",cp," ",n,"downloaded successfully\n ")
        cp+=1
elif(rep==1):
        for i in link:
            video=new(i)
            n=video.title
            print(" \n start download ",n)
            v=video.getbestaudio(preftype="m4a")
            v.download()
            t.write("\n +++++mp3++++ \n ")
            t.write(h)
            t.write(n)
            t.write(": \n ")
            t.write(i)
            t.write("\n =========================================== \n \n \n \n ")
            print(" \n video :",cp," ",n,"downloaded successfully\n ")
            cp+=1
else:
    print("failure !! ")

t.close()
exit()
