
from pafy import new 

print(""" █████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗
╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝
██╗   ██╗ ██████╗ ██╗   ██╗██████╗  ██████╗ ██╗    ██╗███╗   ██╗
╚██╗ ██╔╝██╔═══██╗██║   ██║██╔══██╗██╔═══██╗██║    ██║████╗  ██║
 ╚████╔╝ ██║   ██║██║   ██║██║  ██║██║   ██║██║ █╗ ██║██╔██╗ ██║
  ╚██╔╝  ██║   ██║██║   ██║██║  ██║██║   ██║██║███╗██║██║╚██╗██║
   ██║   ╚██████╔╝╚██████╔╝██████╔╝╚██████╔╝╚███╔███╔╝██║ ╚████║
   ╚═╝    ╚═════╝  ╚═════╝ ╚═════╝  ╚═════╝  ╚══╝╚══╝ ╚═╝  ╚═══╝
            ██╗            ██╗           ██╗
           ███║           ███║          ███║
           ╚██║           ╚██║          ╚██║
            ██║            ██║           ██║
            ██║    ██╗     ██║    ██╗    ██║
            ╚═╝    ╚═╝     ╚═╝    ╚═╝    ╚═╝
█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗█████╗
╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝╚════╝
""")
                            



url = input("Youtube link  :")
video = new(url)
f = open("log.txt", "a+")
f.write(video.title)
f.write(": \n ")
f.write(url)
f.write("\n =========================================== \n")
f.close()
video = new(url)
print("download Format :: \n [1] mp3 \n [2] mp4   ")
rep0=input()
if(rep0=='2'):
    stream = video.streams
    j=0
    print("choose your quality : \n  ")
    for i in stream :
        print("press ",j," to download with ",i,"quality ")
        j+=1
    rep =int(input())
    rep2=str(stream[rep])
    print("confirm your choice Y/N download with \n",rep2[-4:])
    rep3 =input()
    if(rep3 == 'y'):
        stream[rep].download()
        print("downloaded successfully")
    else:
        print(" not confirmed  !!!!!  ")
elif(rep0=='1'):
    audio = video.getbestaudio(preftype="m4a")
    print(" Y/N download mp3 \n")
    rep3 =input()
    if(rep3 == 'y'):
        audio.download()
        print("downloaded successfully")
    else:
        print("failure !! ")
else:
    print("choice not match !!!!")
exit()



